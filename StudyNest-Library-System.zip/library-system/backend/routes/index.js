const express = require('express');
const multer  = require('multer');
const path    = require('path');
const auth    = require('../middleware/auth');

const authCtrl  = require('../controllers/authController');
const stuCtrl   = require('../controllers/studentController');
const feeCtrl   = require('../controllers/feeController');
const miscCtrl  = require('../controllers/miscController');
const db        = require('../config/db');
const { generateReceipt } = require('../utils/pdfReceipt');

const router = express.Router();

// Multer config for photo uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.join(__dirname, '../uploads')),
  filename:    (req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g,'_')}`),
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

// ── Auth ─────────────────────────────────────────────────────
router.post('/auth/login',           authCtrl.login);
router.get ('/auth/me',       auth,  authCtrl.me);
router.post('/auth/change-password', auth, authCtrl.changePassword);

// ── Dashboard ────────────────────────────────────────────────
router.get('/dashboard/stats', auth, miscCtrl.dashboardStats);

// ── Students ─────────────────────────────────────────────────
router.get ('/students',       auth, stuCtrl.getAll);
router.get ('/students/stats', auth, stuCtrl.stats);
router.get ('/students/:id',   auth, stuCtrl.getOne);
router.post('/students',       auth, upload.single('photo'), stuCtrl.create);
router.put ('/students/:id',   auth, upload.single('photo'), stuCtrl.update);
router.delete('/students/:id', auth, stuCtrl.remove);

// ── Seats ────────────────────────────────────────────────────
router.get('/seats',       auth, miscCtrl.getAllSeats);
router.put('/seats/:id',   auth, miscCtrl.updateSeat);

// ── Fees ─────────────────────────────────────────────────────
router.get ('/fees',                   auth, feeCtrl.getAll);
router.get ('/fees/summary',           auth, feeCtrl.summary);
router.post('/fees',                   auth, feeCtrl.create);
router.post('/fees/generate-monthly',  auth, feeCtrl.generateMonthly);

// GET /api/fees/receipt/:receipt_number  — download PDF
router.get('/fees/receipt/:receipt_number', auth, async (req, res) => {
  try {
    const [fees] = await db.query(
      `SELECT f.*, s.name, s.father_name, s.mobile, s.college, s.course, se.seat_number
       FROM fees f
       JOIN students s ON f.student_id = s.id
       LEFT JOIN seats se ON s.seat_id = se.id
       WHERE f.receipt_number = ?`, [req.params.receipt_number]
    );
    if (!fees.length) return res.status(404).json({ success: false, message: 'Receipt not found' });
    const fee = fees[0];
    const student = { name: fee.name, father_name: fee.father_name, mobile: fee.mobile, college: fee.college, course: fee.course };
    const [settings] = await db.query('SELECT * FROM settings LIMIT 1');
    await generateReceipt(res, fee, student, fee.seat_number, settings[0] || {});
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// ── Attendance ───────────────────────────────────────────────
router.get ('/attendance',       auth, miscCtrl.getAttendance);
router.get ('/attendance/stats', auth, miscCtrl.attendanceStats);
router.post('/attendance/checkin',  auth, miscCtrl.checkIn);
router.post('/attendance/checkout', auth, miscCtrl.checkOut);

// ── Notifications ────────────────────────────────────────────
router.get('/notifications',         auth, miscCtrl.getNotifications);
router.put('/notifications/:id/read',auth, miscCtrl.markRead);

// ── Settings ─────────────────────────────────────────────────
router.get('/settings',      auth, miscCtrl.getSettings);
router.put('/settings', auth, upload.single('logo'), miscCtrl.updateSettings);

module.exports = router;
