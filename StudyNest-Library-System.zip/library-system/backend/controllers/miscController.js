const db     = require('../config/db');
const moment = require('moment');

// ── SEATS ────────────────────────────────────────────────────
exports.getAllSeats = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT se.*, s.name as student_name, s.id as student_id
       FROM seats se LEFT JOIN students s ON se.id = s.seat_id AND s.status='active'
       ORDER BY se.row_label, se.seat_number`
    );
    res.json({ success: true, data: rows });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
};

exports.updateSeat = async (req, res) => {
  try {
    const { status } = req.body;
    await db.query('UPDATE seats SET status=? WHERE id=?', [status, req.params.id]);
    res.json({ success: true, message: 'Seat updated' });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
};

// ── ATTENDANCE ───────────────────────────────────────────────
exports.getAttendance = async (req, res) => {
  try {
    const { date, month, year, student_id } = req.query;
    let where = []; let params = [];
    if (date)       { where.push('a.date=?');        params.push(date); }
    if (month)      { where.push('MONTH(a.date)=?'); params.push(month); }
    if (year)       { where.push('YEAR(a.date)=?');  params.push(year); }
    if (student_id) { where.push('a.student_id=?');  params.push(student_id); }

    const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const [rows] = await db.query(
      `SELECT a.*, s.name as student_name, se.seat_number
       FROM attendance a
       JOIN students s ON a.student_id = s.id
       LEFT JOIN seats se ON s.seat_id = se.id
       ${w} ORDER BY a.date DESC, a.check_in DESC`,
      params
    );
    res.json({ success: true, data: rows });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
};

exports.checkIn = async (req, res) => {
  try {
    const { student_id } = req.body;
    const today = moment().format('YYYY-MM-DD');
    const now   = moment().format('HH:mm:ss');

    const [exist] = await db.query(
      'SELECT id FROM attendance WHERE student_id=? AND date=?', [student_id, today]
    );
    if (exist.length) {
      return res.status(400).json({ success: false, message: 'Already checked in today' });
    }
    await db.query(
      'INSERT INTO attendance (student_id,date,check_in,status) VALUES (?,?,?,?)',
      [student_id, today, now, 'present']
    );
    res.json({ success: true, message: 'Check-in recorded', time: now });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
};

exports.checkOut = async (req, res) => {
  try {
    const { student_id } = req.body;
    const today = moment().format('YYYY-MM-DD');
    const now   = moment().format('HH:mm:ss');

    const [exist] = await db.query(
      'SELECT id FROM attendance WHERE student_id=? AND date=?', [student_id, today]
    );
    if (!exist.length) {
      return res.status(400).json({ success: false, message: 'No check-in found today' });
    }
    await db.query(
      'UPDATE attendance SET check_out=? WHERE student_id=? AND date=?',
      [now, student_id, today]
    );
    res.json({ success: true, message: 'Check-out recorded', time: now });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
};

exports.attendanceStats = async (req, res) => {
  try {
    const today = moment().format('YYYY-MM-DD');
    const [[present]] = await db.query(
      'SELECT COUNT(*) as c FROM attendance WHERE date=? AND status="present"', [today]
    );
    const [[total]]   = await db.query('SELECT COUNT(*) as c FROM students WHERE status="active"');
    const absent = total.c - present.c;
    res.json({ success: true, data: { present: present.c, absent, total: total.c, date: today } });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
};

// ── NOTIFICATIONS ────────────────────────────────────────────
exports.getNotifications = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT n.*, s.name as student_name FROM notifications n
       LEFT JOIN students s ON n.student_id = s.id
       ORDER BY n.created_at DESC LIMIT 30`
    );
    const [[{ unread }]] = await db.query(
      'SELECT COUNT(*) as unread FROM notifications WHERE is_read=0'
    );
    res.json({ success: true, data: rows, unread });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
};

exports.markRead = async (req, res) => {
  try {
    await db.query('UPDATE notifications SET is_read=1 WHERE id=?', [req.params.id]);
    res.json({ success: true });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
};

// ── DASHBOARD ────────────────────────────────────────────────
exports.dashboardStats = async (req, res) => {
  try {
    const month = moment().month() + 1;
    const year  = moment().year();
    const today = moment().format('YYYY-MM-DD');

    const [[students]]    = await db.query('SELECT COUNT(*) c FROM students');
    const [[active]]      = await db.query('SELECT COUNT(*) c FROM students WHERE status="active"');
    const [[paidCount]]   = await db.query('SELECT COUNT(*) c FROM fees WHERE payment_status="paid" AND month=? AND year=?', [month, year]);
    const [[paidTotal]]   = await db.query('SELECT COALESCE(SUM(fee_amount),0) t FROM fees WHERE payment_status="paid" AND month=? AND year=?', [month, year]);
    const [[pendingCount]]= await db.query('SELECT COUNT(*) c FROM fees WHERE payment_status IN ("pending","overdue") AND month=? AND year=?', [month, year]);
    const [[pendingAmt]]  = await db.query('SELECT COALESCE(SUM(fee_amount),0) t FROM fees WHERE payment_status IN ("pending","overdue") AND month=? AND year=?', [month, year]);
    const [[seatsEmpty]]  = await db.query('SELECT COUNT(*) c FROM seats WHERE status="available"');
    const [[seatsOccupied]]= await db.query('SELECT COUNT(*) c FROM seats WHERE status="occupied"');
    const [[todayPaid]]   = await db.query('SELECT COALESCE(SUM(fee_amount),0) t FROM fees WHERE payment_date=? AND payment_status="paid"', [today]);
    const [[presentToday]]= await db.query('SELECT COUNT(*) c FROM attendance WHERE date=? AND status="present"', [today]);

    // Monthly income for current year
    const [monthlyIncome] = await db.query(
      `SELECT month, SUM(fee_amount) as total FROM fees
       WHERE year=? AND payment_status='paid'
       GROUP BY month ORDER BY month`, [year]
    );

    // Recent payments
    const [recentPayments] = await db.query(
      `SELECT f.*, s.name as student_name, se.seat_number
       FROM fees f JOIN students s ON f.student_id=s.id
       LEFT JOIN seats se ON s.seat_id=se.id
       WHERE f.payment_status='paid'
       ORDER BY f.payment_date DESC LIMIT 5`
    );

    res.json({
      success: true,
      data: {
        totalStudents: students.c,
        activeStudents: active.c,
        paidCount: paidCount.c,
        monthlyCollection: paidTotal.t,
        pendingCount: pendingCount.c,
        pendingAmount: pendingAmt.t,
        emptySeats: seatsEmpty.c,
        occupiedSeats: seatsOccupied.c,
        todayCollection: todayPaid.t,
        presentToday: presentToday.c,
        monthlyIncome,
        recentPayments,
      }
    });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
};

// ── SETTINGS ─────────────────────────────────────────────────
exports.getSettings = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM settings LIMIT 1');
    res.json({ success: true, data: rows[0] || {} });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
};

exports.updateSettings = async (req, res) => {
  try {
    const fields = ['library_name','address','phone','email','upi_id','default_fee',
                    'security_deposit','late_charge_per_day','morning_start','morning_end',
                    'evening_start','evening_end','total_seats'];
    const updates = fields.filter(f => req.body[f] !== undefined)
                          .map(f => `${f}=?`).join(', ');
    const values  = fields.filter(f => req.body[f] !== undefined).map(f => req.body[f]);

    if (req.file) {
      values.push(`/uploads/${req.file.filename}`);
      await db.query(`UPDATE settings SET ${updates}, logo_url=? WHERE id=1`, values);
    } else {
      await db.query(`UPDATE settings SET ${updates} WHERE id=1`, values);
    }
    res.json({ success: true, message: 'Settings updated' });
  } catch (err) { res.status(500).json({ success: false, message: err.message }); }
};
