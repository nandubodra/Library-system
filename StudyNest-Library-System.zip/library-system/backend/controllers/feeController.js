const db     = require('../config/db');
const moment = require('moment');

// GET /api/fees?month=&year=&status=&student_id=
exports.getAll = async (req, res) => {
  try {
    const { month, year, status, student_id, page = 1, limit = 20 } = req.query;
    let where = []; let params = [];

    if (month)      { where.push('f.month=?');          params.push(month); }
    if (year)       { where.push('f.year=?');           params.push(year); }
    if (status)     { where.push('f.payment_status=?'); params.push(status); }
    if (student_id) { where.push('f.student_id=?');     params.push(student_id); }

    const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const offset = (page - 1) * limit;

    const [rows] = await db.query(
      `SELECT f.*, s.name as student_name, s.mobile, se.seat_number
       FROM fees f
       JOIN students s  ON f.student_id = s.id
       LEFT JOIN seats se ON s.seat_id = se.id
       ${w} ORDER BY f.year DESC, f.month DESC, f.created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, Number(limit), offset]
    );
    const [[{ total }]] = await db.query(
      `SELECT COUNT(*) as total FROM fees f JOIN students s ON f.student_id=s.id ${w}`, params
    );
    res.json({ success: true, data: rows, total });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /api/fees  — record a payment
exports.create = async (req, res) => {
  try {
    const { student_id, month, year, fee_amount, payment_mode, transaction_id, notes } = req.body;
    const now = moment();

    const receipt_number = `RCP-${year}-${String(now.valueOf()).slice(-6)}`;
    const due_date = moment(`${year}-${String(month).padStart(2,'0')}-01`).endOf('month').format('YYYY-MM-DD');

    const [exist] = await db.query(
      'SELECT id FROM fees WHERE student_id=? AND month=? AND year=?', [student_id, month, year]
    );
    if (exist.length) {
      // Update existing record to paid
      await db.query(
        `UPDATE fees SET payment_status='paid', payment_date=?, payment_mode=?,
         transaction_id=?, receipt_number=?, notes=?, fee_amount=? WHERE id=?`,
        [now.format('YYYY-MM-DD'), payment_mode, transaction_id, receipt_number, notes, fee_amount, exist[0].id]
      );
      // Notification
      await db.query(
        'INSERT INTO notifications (type,message,student_id) VALUES (?,?,?)',
        ['payment_received', `Fee received for month ${month}/${year}`, student_id]
      );
      return res.json({ success: true, message: 'Payment recorded', receipt_number });
    }

    await db.query(
      `INSERT INTO fees (student_id,month,year,fee_amount,payment_status,due_date,
        payment_date,payment_mode,transaction_id,receipt_number,notes)
       VALUES (?,?,?,?,'paid',?,?,?,?,?,?)`,
      [student_id, month, year, fee_amount, due_date,
       now.format('YYYY-MM-DD'), payment_mode, transaction_id, receipt_number, notes]
    );
    await db.query(
      'INSERT INTO notifications (type,message,student_id) VALUES (?,?,?)',
      ['payment_received', `Fee received for month ${month}/${year}`, student_id]
    );
    res.status(201).json({ success: true, message: 'Payment recorded', receipt_number });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// GET /api/fees/summary?month=&year=
exports.summary = async (req, res) => {
  try {
    const month = req.query.month || moment().month() + 1;
    const year  = req.query.year  || moment().year();

    const [[paid]] = await db.query(
      `SELECT COUNT(*) as cnt, COALESCE(SUM(fee_amount),0) as total
       FROM fees WHERE month=? AND year=? AND payment_status='paid'`, [month, year]
    );
    const [[pending]] = await db.query(
      `SELECT COUNT(*) as cnt, COALESCE(SUM(fee_amount),0) as total
       FROM fees WHERE month=? AND year=? AND payment_status='pending'`, [month, year]
    );
    const [[overdue]] = await db.query(
      `SELECT COUNT(*) as cnt, COALESCE(SUM(fee_amount),0) as total
       FROM fees WHERE month=? AND year=? AND payment_status='overdue'`, [month, year]
    );
    const [monthly] = await db.query(
      `SELECT month, year, SUM(fee_amount) as total
       FROM fees WHERE payment_status='paid' AND year=?
       GROUP BY month, year ORDER BY month`, [year]
    );
    res.json({ success: true, data: { paid, pending, overdue, monthly } });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /api/fees/generate-monthly — auto-generate pending fees for all active students
exports.generateMonthly = async (req, res) => {
  try {
    const { month, year } = req.body;
    const [students] = await db.query(
      'SELECT id, monthly_fee, joining_date FROM students WHERE status="active"'
    );
    const due_date = moment(`${year}-${String(month).padStart(2,'0')}-01`).endOf('month').format('YYYY-MM-DD');
    let created = 0;

    for (const s of students) {
      const [exist] = await db.query(
        'SELECT id FROM fees WHERE student_id=? AND month=? AND year=?', [s.id, month, year]
      );
      if (!exist.length) {
        await db.query(
          `INSERT INTO fees (student_id,month,year,fee_amount,payment_status,due_date)
           VALUES (?,?,?,?,'pending',?)`,
          [s.id, month, year, s.monthly_fee, due_date]
        );
        created++;
      }
    }
    // Mark overdue: past due_date and still pending
    await db.query(
      `UPDATE fees SET payment_status='overdue'
       WHERE payment_status='pending' AND due_date < CURDATE()`
    );
    res.json({ success: true, message: `Generated ${created} fee records` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
