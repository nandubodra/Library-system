const db = require('../config/db');

// GET /api/students
exports.getAll = async (req, res) => {
  try {
    const { search, status, timing, page = 1, limit = 20 } = req.query;
    let where = [];
    let params = [];

    if (search) {
      where.push('(s.name LIKE ? OR s.mobile LIKE ? OR s.college LIKE ? OR se.seat_number LIKE ?)');
      const q = `%${search}%`;
      params.push(q, q, q, q);
    }
    if (status) { where.push('s.status = ?'); params.push(status); }
    if (timing) { where.push('s.library_timing = ?'); params.push(timing); }

    const whereStr = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const offset = (page - 1) * limit;

    const [rows] = await db.query(
      `SELECT s.*, se.seat_number FROM students s
       LEFT JOIN seats se ON s.seat_id = se.id
       ${whereStr} ORDER BY s.created_at DESC LIMIT ? OFFSET ?`,
      [...params, Number(limit), offset]
    );
    const [[{ total }]] = await db.query(
      `SELECT COUNT(*) as total FROM students s LEFT JOIN seats se ON s.seat_id = se.id ${whereStr}`,
      params
    );
    res.json({ success: true, data: rows, total, page: Number(page), limit: Number(limit) });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// GET /api/students/:id
exports.getOne = async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT s.*, se.seat_number FROM students s
       LEFT JOIN seats se ON s.seat_id = se.id WHERE s.id = ?`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ success: false, message: 'Student not found' });
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

// POST /api/students
exports.create = async (req, res) => {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const {
      name, father_name, mobile, email, address, college, course, aadhaar,
      seat_id, joining_date, monthly_fee, security_deposit, library_timing, status
    } = req.body;

    const photo_url = req.file ? `/uploads/${req.file.filename}` : null;

    const [result] = await conn.query(
      `INSERT INTO students (name,father_name,mobile,email,address,college,course,aadhaar,
        seat_id,photo_url,joining_date,monthly_fee,security_deposit,library_timing,status)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [name,father_name,mobile,email,address,college,course,aadhaar,
       seat_id||null,photo_url,joining_date,monthly_fee||1500,security_deposit||2000,
       library_timing||'full_day',status||'active']
    );

    if (seat_id) {
      await conn.query('UPDATE seats SET status="occupied" WHERE id=?', [seat_id]);
    }

    // Create notification
    await conn.query(
      `INSERT INTO notifications (type,message,student_id) VALUES (?,?,?)`,
      ['new_student', `New student ${name} joined with seat assignment`, result.insertId]
    );

    await conn.commit();
    res.status(201).json({ success: true, message: 'Student added', id: result.insertId });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: err.message });
  } finally {
    conn.release();
  }
};

// PUT /api/students/:id
exports.update = async (req, res) => {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const {
      name, father_name, mobile, email, address, college, course, aadhaar,
      seat_id, joining_date, monthly_fee, security_deposit, library_timing, status
    } = req.body;

    const [old] = await conn.query('SELECT seat_id FROM students WHERE id=?', [req.params.id]);
    if (!old.length) return res.status(404).json({ success: false, message: 'Not found' });

    const photo_url = req.file ? `/uploads/${req.file.filename}` : undefined;
    const photoClause = photo_url ? ', photo_url=?' : '';
    const photoParam  = photo_url ? [photo_url] : [];

    await conn.query(
      `UPDATE students SET name=?,father_name=?,mobile=?,email=?,address=?,college=?,
       course=?,aadhaar=?,seat_id=?,joining_date=?,monthly_fee=?,security_deposit=?,
       library_timing=?,status=?${photoClause} WHERE id=?`,
      [name,father_name,mobile,email,address,college,course,aadhaar,
       seat_id||null,joining_date,monthly_fee,security_deposit,library_timing,status,
       ...photoParam, req.params.id]
    );

    // Update seat statuses
    const oldSeatId = old[0].seat_id;
    if (oldSeatId && oldSeatId != seat_id) {
      await conn.query('UPDATE seats SET status="available" WHERE id=?', [oldSeatId]);
    }
    if (seat_id) {
      await conn.query('UPDATE seats SET status="occupied" WHERE id=?', [seat_id]);
    }

    await conn.commit();
    res.json({ success: true, message: 'Student updated' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: err.message });
  } finally {
    conn.release();
  }
};

// DELETE /api/students/:id
exports.remove = async (req, res) => {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [rows] = await conn.query('SELECT seat_id FROM students WHERE id=?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ success: false, message: 'Not found' });

    if (rows[0].seat_id) {
      await conn.query('UPDATE seats SET status="available" WHERE id=?', [rows[0].seat_id]);
    }
    await conn.query('DELETE FROM students WHERE id=?', [req.params.id]);
    await conn.commit();
    res.json({ success: true, message: 'Student deleted' });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ success: false, message: err.message });
  } finally {
    conn.release();
  }
};

// GET /api/students/stats
exports.stats = async (req, res) => {
  try {
    const [[total]]    = await db.query('SELECT COUNT(*) as c FROM students');
    const [[active]]   = await db.query('SELECT COUNT(*) as c FROM students WHERE status="active"');
    const [[inactive]] = await db.query('SELECT COUNT(*) as c FROM students WHERE status="inactive"');
    const [[morning]]  = await db.query('SELECT COUNT(*) as c FROM students WHERE library_timing="morning"');
    const [[evening]]  = await db.query('SELECT COUNT(*) as c FROM students WHERE library_timing="evening"');
    const [[fullday]]  = await db.query('SELECT COUNT(*) as c FROM students WHERE library_timing="full_day"');
    res.json({ success:true, data:{ total:total.c, active:active.c, inactive:inactive.c, morning:morning.c, evening:evening.c, fullday:fullday.c }});
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};
