/**
 * Run this once to create the default admin user:
 *   node seed-admin.js
 */
require('dotenv').config();
const bcrypt = require('bcrypt');
const db     = require('./config/db');

async function seed() {
  const hash = await bcrypt.hash('admin123', 10);
  await db.query(
    'INSERT INTO admins (name, email, password, phone) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE password=?',
    ['Admin', 'admin@studynest.com', hash, '+91 98765 43210', hash]
  );
  console.log('✅ Admin seeded: admin@studynest.com / admin123');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
