const PDFDocument = require('pdfkit');
const QRCode      = require('qrcode');
const moment      = require('moment');

const MONTHS = ['','January','February','March','April','May','June',
                'July','August','September','October','November','December'];

async function generateReceipt(res, fee, student, seat, settings) {
  const doc = new PDFDocument({ size: 'A5', margin: 30 });

  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="receipt-${fee.receipt_number}.pdf"`);
  doc.pipe(res);

  // ── Header ──────────────────────────────────────────
  doc.rect(0, 0, doc.page.width, 70).fill('#1e2235');

  doc.fillColor('#ffffff')
     .fontSize(16).font('Helvetica-Bold')
     .text(settings.library_name || 'StudyNest Library', 30, 18);
  doc.fontSize(8).font('Helvetica')
     .text(settings.address || '', 30, 38)
     .text(`${settings.phone || ''}  |  ${settings.email || ''}`, 30, 50);

  // Receipt title band
  doc.rect(0, 70, doc.page.width, 28).fill('#6366f1');
  doc.fillColor('#ffffff').fontSize(12).font('Helvetica-Bold')
     .text('PAYMENT RECEIPT', 0, 78, { align: 'center' });

  // ── Receipt meta ────────────────────────────────────
  doc.fillColor('#1a1d2e').fontSize(9).font('Helvetica')
     .text(`Receipt No: ${fee.receipt_number}`, 30, 112)
     .text(`Date: ${moment(fee.payment_date).format('DD MMM YYYY')}`, 0, 112, { align: 'right', width: doc.page.width - 30 });

  // Divider
  doc.moveTo(30, 130).lineTo(doc.page.width - 30, 130).strokeColor('#e2e8f0').lineWidth(1).stroke();

  // ── Student Details Box ──────────────────────────────
  doc.rect(30, 138, doc.page.width - 60, 90).fill('#f8fafc').stroke('#e2e8f0');
  doc.fillColor('#64748b').fontSize(8).font('Helvetica-Bold')
     .text('STUDENT DETAILS', 40, 146);

  const details = [
    ['Name',    student.name],
    ['Father',  student.father_name || '—'],
    ['Mobile',  student.mobile],
    ['College', student.college || '—'],
    ['Course',  student.course  || '—'],
    ['Seat',    seat || '—'],
  ];
  let dy = 158;
  details.forEach(([label, val], i) => {
    const x = i % 2 === 0 ? 40 : doc.page.width / 2;
    if (i % 2 === 0 && i > 0) dy += 16;
    doc.fillColor('#94a3b8').fontSize(7).font('Helvetica').text(label + ':', x, dy);
    doc.fillColor('#1e293b').fontSize(8).font('Helvetica-Bold').text(val, x + 45, dy);
  });

  // ── Payment Details ──────────────────────────────────
  dy = 245;
  doc.fillColor('#64748b').fontSize(8).font('Helvetica-Bold').text('PAYMENT DETAILS', 30, dy);
  dy += 12;
  doc.moveTo(30, dy).lineTo(doc.page.width - 30, dy).strokeColor('#e2e8f0').stroke();

  const payRows = [
    ['Month / Year',   `${MONTHS[fee.month]} ${fee.year}`],
    ['Fee Amount',     `₹${Number(fee.fee_amount).toLocaleString('en-IN')}`],
    ['Late Charges',   `₹${Number(fee.late_charge || 0).toLocaleString('en-IN')}`],
    ['Payment Mode',   (fee.payment_mode || '').toUpperCase()],
    ['Transaction ID', fee.transaction_id || '—'],
  ];
  payRows.forEach(([label, val]) => {
    dy += 14;
    doc.fillColor('#64748b').fontSize(8).font('Helvetica').text(label, 30, dy);
    doc.fillColor('#1e293b').fontSize(8).font('Helvetica-Bold').text(val, 0, dy, { align: 'right', width: doc.page.width - 30 });
  });

  // Total paid
  dy += 18;
  doc.rect(30, dy, doc.page.width - 60, 28).fill('#10b981');
  doc.fillColor('#ffffff').fontSize(10).font('Helvetica-Bold')
     .text('TOTAL PAID', 40, dy + 8)
     .text(`₹${Number(fee.fee_amount).toLocaleString('en-IN')}`, 0, dy + 8, { align: 'right', width: doc.page.width - 40 });

  // ── QR Code ─────────────────────────────────────────
  const qrData = `Receipt:${fee.receipt_number}|Student:${student.name}|Amount:${fee.fee_amount}|Month:${MONTHS[fee.month]} ${fee.year}`;
  const qrBuffer = await QRCode.toBuffer(qrData, { width: 70, margin: 1 });
  doc.image(qrBuffer, doc.page.width - 100, dy + 40, { width: 70 });
  doc.fillColor('#94a3b8').fontSize(7).text('Scan to verify', doc.page.width - 100, dy + 114, { width: 70, align: 'center' });

  // ── Footer ──────────────────────────────────────────
  const footerY = doc.page.height - 40;
  doc.moveTo(30, footerY - 10).lineTo(doc.page.width - 30, footerY - 10).strokeColor('#e2e8f0').stroke();
  doc.fillColor('#94a3b8').fontSize(7).font('Helvetica')
     .text('Thank you for your payment. This is a system-generated receipt.', 30, footerY, { align: 'center', width: doc.page.width - 60 });

  doc.end();
}

module.exports = { generateReceipt };
