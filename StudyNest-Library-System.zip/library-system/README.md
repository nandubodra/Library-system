# 📚 StudyNest Library Management System

A modern, full-stack library management system for personal study libraries / reading rooms.  
Built with **React + Tailwind + Node.js + Express + MySQL + JWT**.

---

## ✨ Features

| Module | Features |
|---|---|
| 🔐 **Auth** | JWT login, bcrypt passwords, protected routes |
| 📊 **Dashboard** | Stats cards, bar charts, doughnut chart, recent payments |
| 👥 **Students** | Add / edit / delete, photo upload, search & filter, pagination |
| 💺 **Seats** | Visual A–E row layout, color-coded status, click to manage |
| 💳 **Fees** | Monthly fee tracking, record payments, auto-generate, overdue detection |
| 🧾 **Receipts** | PDF receipts with QR code, print-ready |
| ✅ **Attendance** | Daily check-in / check-out, calendar view, stats |
| 📈 **Reports** | Annual income charts, student growth, monthly progress bars |
| ⚙️ **Settings** | Library info, fee config, timings, logo, change password |

---

## 🚀 Quick Setup

### Prerequisites
- Node.js 18+
- MySQL 8+
- npm

---

### 1. Clone & Setup

```bash
git clone <your-repo>
cd library-system
```

---

### 2. Database Setup

```bash
# Login to MySQL
mysql -u root -p

# Run the schema
mysql -u root -p < database.sql
```

---

### 3. Backend Setup

```bash
cd backend
npm install

# Copy and edit env
cp .env.example .env
# Edit .env: set DB_PASSWORD and JWT_SECRET

# Seed admin user
node seed-admin.js

# Start server
npm run dev        # development (nodemon)
npm start          # production
```

Backend runs at: **http://localhost:5000**

Default admin credentials:
- Email: `admin@studynest.com`
- Password: `admin123`

---

### 4. Frontend Setup

```bash
cd frontend
npm install
npm start          # development
npm run build      # production build
```

Frontend runs at: **http://localhost:3000**

The React app proxies `/api` calls to `http://localhost:5000` automatically.

---

## 📁 Project Structure

```
library-system/
├── database.sql                # MySQL schema + seed data
├── backend/
│   ├── server.js               # Express entry point
│   ├── .env.example            # Environment template
│   ├── seed-admin.js           # Admin seeder
│   ├── config/
│   │   └── db.js               # MySQL connection pool
│   ├── middleware/
│   │   └── auth.js             # JWT middleware
│   ├── controllers/
│   │   ├── authController.js   # Login, change password
│   │   ├── studentController.js # Student CRUD
│   │   ├── feeController.js    # Fee tracking + generation
│   │   └── miscController.js   # Seats, Attendance, Notifications, Dashboard, Settings
│   ├── routes/
│   │   └── index.js            # All API routes
│   ├── utils/
│   │   └── pdfReceipt.js       # PDF generation with QRCode
│   └── uploads/                # Student photos & logos (auto-created)
└── frontend/
    ├── public/index.html
    ├── tailwind.config.js
    └── src/
        ├── App.jsx             # Router + layout
        ├── index.js            # React entry
        ├── styles/index.css    # Global styles + Tailwind
        ├── utils/api.js        # Axios instance with JWT
        ├── hooks/useAuth.js    # Auth context
        ├── components/
        │   └── shared/
        │       └── Sidebar.jsx
        └── pages/
            ├── Login.jsx
            ├── Dashboard.jsx
            ├── Students.jsx
            ├── Seats.jsx
            ├── Fees.jsx
            ├── Receipts.jsx
            ├── Attendance.jsx
            ├── Reports.jsx
            └── Settings.jsx
```

---

## 🔌 API Reference

### Auth
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/login` | Login → returns JWT |
| GET  | `/api/auth/me` | Get logged-in admin |
| POST | `/api/auth/change-password` | Change password |

### Students
| Method | Endpoint | Description |
|---|---|---|
| GET    | `/api/students` | List with search/filter/pagination |
| GET    | `/api/students/stats` | Summary counts |
| GET    | `/api/students/:id` | Single student |
| POST   | `/api/students` | Add student (multipart) |
| PUT    | `/api/students/:id` | Edit student |
| DELETE | `/api/students/:id` | Delete student |

### Fees
| Method | Endpoint | Description |
|---|---|---|
| GET  | `/api/fees` | List fees with filters |
| GET  | `/api/fees/summary` | Monthly summary |
| POST | `/api/fees` | Record a payment |
| POST | `/api/fees/generate-monthly` | Auto-generate pending fees |
| GET  | `/api/fees/receipt/:no` | Download PDF receipt |

### Seats
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/seats` | All seats with student info |
| PUT | `/api/seats/:id` | Update seat status |

### Attendance
| Method | Endpoint | Description |
|---|---|---|
| GET  | `/api/attendance` | Records by date/month/student |
| GET  | `/api/attendance/stats` | Today's stats |
| POST | `/api/attendance/checkin` | Mark check-in |
| POST | `/api/attendance/checkout` | Mark check-out |

### Other
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/dashboard/stats` | Full dashboard data |
| GET | `/api/notifications` | Unread notifications |
| GET | `/api/settings` | Library settings |
| PUT | `/api/settings` | Update settings |

---

## 🛡️ Security

- All `/api/*` routes (except `/api/auth/login`) require `Authorization: Bearer <token>`
- Passwords hashed with bcrypt (10 rounds)
- JWT expires in 7 days
- File uploads limited to 5MB

---

## 🚢 Deployment Tips

### Backend (PM2)
```bash
npm install -g pm2
pm2 start server.js --name studynest-api
pm2 save
```

### Frontend (Nginx)
```bash
npm run build
# Copy build/ to /var/www/studynest
# Configure nginx to serve build/index.html for all routes
```

### MySQL (Production)
- Create a dedicated DB user instead of root
- Enable SSL for DB connections
- Set up regular mysqldump backups

---

## 📞 Support

Built for **StudyNest Library, Patna**.  
Customize `settings` table defaults for your library name, fees, and timings.
