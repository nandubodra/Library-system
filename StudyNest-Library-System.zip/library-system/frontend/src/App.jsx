import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './hooks/useAuth';
import Sidebar from './components/shared/Sidebar';

import Login      from './pages/Login';
import Dashboard  from './pages/Dashboard';
import Students   from './pages/Students';
import Seats      from './pages/Seats';
import Fees       from './pages/Fees';
import Receipts   from './pages/Receipts';
import Attendance from './pages/Attendance';
import Reports    from './pages/Reports';
import Settings   from './pages/Settings';

function Layout() {
  const { admin } = useAuth();
  if (!admin) return <Navigate to="/login" replace />;
  return (
    <div className="flex min-h-screen bg-dark-900">
      <Sidebar />
      <main className="flex-1 p-6 overflow-y-auto max-h-screen">
        <Outlet />
      </main>
    </div>
  );
}

function PublicRoute() {
  const { admin } = useAuth();
  if (admin) return <Navigate to="/dashboard" replace />;
  return <Outlet />;
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Toaster
          position="top-right"
          toastOptions={{
            style: { background: '#1e2235', color: '#e2e8f0', border: '1px solid rgba(99,102,241,0.2)', fontSize: '13px' },
            success: { iconTheme: { primary: '#10b981', secondary: '#fff' } },
            error:   { iconTheme: { primary: '#ef4444', secondary: '#fff' } },
          }}
        />
        <Routes>
          <Route element={<PublicRoute />}>
            <Route path="/login" element={<Login />} />
          </Route>
          <Route element={<Layout />}>
            <Route path="/"           element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard"  element={<Dashboard />} />
            <Route path="/students"   element={<Students />} />
            <Route path="/seats"      element={<Seats />} />
            <Route path="/fees"       element={<Fees />} />
            <Route path="/receipts"   element={<Receipts />} />
            <Route path="/attendance" element={<Attendance />} />
            <Route path="/reports"    element={<Reports />} />
            <Route path="/settings"   element={<Settings />} />
          </Route>
          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
