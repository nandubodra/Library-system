import React, { useEffect, useState, useCallback } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

const MONTHS = ['','January','February','March','April','May','June','July','August','September','October','November','December'];
const PILL = { paid:'bg-green-500/15 text-green-400', pending:'bg-amber-500/15 text-amber-400', overdue:'bg-red-500/15 text-red-400' };

export default function Fees() {
  const now = new Date();
  const [fees, setFees]         = useState([]);
  const [summary, setSummary]   = useState(null);
  const [students, setStudents] = useState([]);
  const [filterMonth, setFilterMonth] = useState(now.getMonth() + 1);
  const [filterYear, setFilterYear]   = useState(now.getFullYear());
  const [filterStatus, setFilterStatus] = useState('');
  const [loading, setLoading]   = useState(true);
  const [modal, setModal]       = useState(false);
  const [form, setForm]         = useState({ student_id:'', month: now.getMonth()+1, year: now.getFullYear(), fee_amount:'', payment_mode:'cash', transaction_id:'', notes:'' });
  const [saving, setSaving]     = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [feesRes, sumRes] = await Promise.all([
        api.get('/fees', { params: { month: filterMonth, year: filterYear, status: filterStatus, limit: 50 } }),
        api.get('/fees/summary', { params: { month: filterMonth, year: filterYear } }),
      ]);
      setFees(feesRes.data.data);
      setSummary(sumRes.data.data);
    } catch { toast.error('Failed to load fees'); }
    finally { setLoading(false); }
  }, [filterMonth, filterYear, filterStatus]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    api.get('/students', { params: { status: 'active', limit: 200 } }).then(r => setStudents(r.data.data));
  }, []);

  const handleGenerate = async () => {
    try {
      await api.post('/fees/generate-monthly', { month: filterMonth, year: filterYear });
      toast.success('Monthly fees generated!');
      load();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
  };

  const handleSave = async e => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.post('/fees', form);
      toast.success('Payment recorded!');
      setModal(false);
      load();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
    finally { setSaving(false); }
  };

  const downloadReceipt = (receiptNo) => {
    window.open(`/api/fees/receipt/${receiptNo}`, '_blank');
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-white">Fee Tracking</h1>
          <p className="text-slate-400 text-sm">{MONTHS[filterMonth]} {filterYear}</p>
        </div>
        <div className="flex gap-2">
          <button onClick={handleGenerate} className="bg-dark-600 border border-white/10 text-slate-300 hover:text-white px-4 py-2 rounded-xl text-sm font-medium transition flex items-center gap-2">
            ⚡ Generate Monthly
          </button>
          <button onClick={() => setModal(true)} className="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition">
            + Record Payment
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      {summary && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-dark-600 border border-white/5 rounded-2xl p-4">
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Collected</p>
            <p className="text-2xl font-bold text-green-400">₹{Number(summary.paid?.total||0).toLocaleString('en-IN')}</p>
            <p className="text-xs text-slate-500 mt-1">{summary.paid?.cnt || 0} students</p>
          </div>
          <div className="bg-dark-600 border border-white/5 rounded-2xl p-4">
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Pending</p>
            <p className="text-2xl font-bold text-amber-400">₹{Number(summary.pending?.total||0).toLocaleString('en-IN')}</p>
            <p className="text-xs text-slate-500 mt-1">{summary.pending?.cnt || 0} students</p>
          </div>
          <div className="bg-dark-600 border border-white/5 rounded-2xl p-4">
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Overdue</p>
            <p className="text-2xl font-bold text-red-400">₹{Number(summary.overdue?.total||0).toLocaleString('en-IN')}</p>
            <p className="text-xs text-slate-500 mt-1">{summary.overdue?.cnt || 0} students</p>
          </div>
          <div className="bg-dark-600 border border-white/5 rounded-2xl p-4">
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">Collection Rate</p>
            <p className="text-2xl font-bold text-primary-400">
              {summary.paid?.cnt && (summary.paid.cnt + (summary.pending?.cnt||0) + (summary.overdue?.cnt||0)) > 0
                ? Math.round(summary.paid.cnt / (summary.paid.cnt + (summary.pending?.cnt||0) + (summary.overdue?.cnt||0)) * 100)
                : 0}%
            </p>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex gap-3 mb-4 flex-wrap">
        <select value={filterMonth} onChange={e => setFilterMonth(e.target.value)}
          className="bg-dark-600 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-primary-500">
          {MONTHS.slice(1).map((m,i) => <option key={i+1} value={i+1}>{m}</option>)}
        </select>
        <select value={filterYear} onChange={e => setFilterYear(e.target.value)}
          className="bg-dark-600 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-primary-500">
          {[2023,2024,2025,2026].map(y => <option key={y} value={y}>{y}</option>)}
        </select>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)}
          className="bg-dark-600 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-primary-500">
          <option value="">All Status</option>
          <option value="paid">Paid</option>
          <option value="pending">Pending</option>
          <option value="overdue">Overdue</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-dark-600 border border-white/5 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5">
                {['Student','Seat','Month','Amount','Due Date','Paid On','Mode','Status','Receipt'].map(h => (
                  <th key={h} className="text-left text-[10px] font-bold uppercase tracking-wider text-slate-500 px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={9} className="text-center py-12 text-slate-500">Loading...</td></tr>
              ) : fees.length === 0 ? (
                <tr><td colSpan={9} className="text-center py-12 text-slate-500">No records. Click "Generate Monthly" to create fee records.</td></tr>
              ) : fees.map(f => (
                <tr key={f.id} className="border-t border-white/[0.04] hover:bg-white/[0.02] transition">
                  <td className="px-4 py-3 text-white font-medium">{f.student_name}</td>
                  <td className="px-4 py-3"><span className="bg-primary-500/15 text-primary-300 px-2 py-0.5 rounded-md text-xs font-bold">{f.seat_number||'—'}</span></td>
                  <td className="px-4 py-3 text-slate-400 text-xs">{MONTHS[f.month]} {f.year}</td>
                  <td className="px-4 py-3 text-green-400 font-semibold">₹{Number(f.fee_amount).toLocaleString('en-IN')}</td>
                  <td className="px-4 py-3 text-slate-400 text-xs">{f.due_date ? new Date(f.due_date).toLocaleDateString('en-IN') : '—'}</td>
                  <td className="px-4 py-3 text-slate-300 text-xs">{f.payment_date ? new Date(f.payment_date).toLocaleDateString('en-IN') : '—'}</td>
                  <td className="px-4 py-3 text-slate-400 text-xs capitalize">{f.payment_mode || '—'}</td>
                  <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-[10px] font-bold capitalize ${PILL[f.payment_status]}`}>{f.payment_status}</span></td>
                  <td className="px-4 py-3">
                    {f.receipt_number && (
                      <button onClick={() => downloadReceipt(f.receipt_number)} className="text-primary-400 hover:text-primary-300 text-xs underline">PDF</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Payment Modal */}
      {modal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-dark-700 border border-white/10 rounded-2xl w-full max-w-md">
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
              <h2 className="font-bold text-white">Record Payment</h2>
              <button onClick={() => setModal(false)} className="text-slate-400 hover:text-white text-xl">×</button>
            </div>
            <form onSubmit={handleSave} className="p-6 space-y-4">
              <div>
                <label className="block text-xs text-slate-400 font-medium mb-1.5">Student *</label>
                <select required value={form.student_id} onChange={e => {
                  const s = students.find(st => st.id == e.target.value);
                  setForm(p => ({ ...p, student_id: e.target.value, fee_amount: s?.monthly_fee || '' }));
                }} className="w-full bg-dark-800 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500">
                  <option value="">Select student...</option>
                  {students.map(s => <option key={s.id} value={s.id}>{s.name} — {s.seat_number || 'No seat'}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-400 font-medium mb-1.5">Month</label>
                  <select value={form.month} onChange={e => setForm(p => ({ ...p, month: e.target.value }))}
                    className="w-full bg-dark-800 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500">
                    {MONTHS.slice(1).map((m,i) => <option key={i+1} value={i+1}>{m}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-slate-400 font-medium mb-1.5">Year</label>
                  <select value={form.year} onChange={e => setForm(p => ({ ...p, year: e.target.value }))}
                    className="w-full bg-dark-800 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500">
                    {[2023,2024,2025,2026].map(y => <option key={y} value={y}>{y}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-xs text-slate-400 font-medium mb-1.5">Fee Amount (₹) *</label>
                <input type="number" required value={form.fee_amount} onChange={e => setForm(p => ({ ...p, fee_amount: e.target.value }))}
                  className="w-full bg-dark-800 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500" />
              </div>
              <div>
                <label className="block text-xs text-slate-400 font-medium mb-1.5">Payment Mode</label>
                <select value={form.payment_mode} onChange={e => setForm(p => ({ ...p, payment_mode: e.target.value }))}
                  className="w-full bg-dark-800 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500">
                  <option value="cash">Cash</option>
                  <option value="upi">UPI</option>
                  <option value="bank_transfer">Bank Transfer</option>
                  <option value="cheque">Cheque</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-400 font-medium mb-1.5">Transaction ID (optional)</label>
                <input type="text" value={form.transaction_id} onChange={e => setForm(p => ({ ...p, transaction_id: e.target.value }))}
                  className="w-full bg-dark-800 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500" />
              </div>
              <div className="flex gap-3 justify-end pt-2">
                <button type="button" onClick={() => setModal(false)} className="px-5 py-2 rounded-xl bg-dark-800 border border-white/10 text-sm text-slate-300 hover:text-white transition">Cancel</button>
                <button type="submit" disabled={saving} className="px-5 py-2 rounded-xl bg-primary-500 hover:bg-primary-600 text-white text-sm font-semibold transition">
                  {saving ? '⏳ Saving...' : '✅ Record Payment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
