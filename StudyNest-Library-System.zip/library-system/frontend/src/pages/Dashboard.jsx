import React, { useEffect, useState } from 'react';
import { Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement,
  Title, Tooltip, Legend, ArcElement
} from 'chart.js';
import api from '../utils/api';
import toast from 'react-hot-toast';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend, ArcElement);

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function StatCard({ label, value, sub, icon, color }) {
  return (
    <div className="bg-dark-600 border border-white/5 rounded-2xl p-5">
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider">{label}</p>
        <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-base ${color}`}>{icon}</div>
      </div>
      <p className="text-3xl font-bold text-white">{value}</p>
      {sub && <p className="text-xs text-slate-500 mt-1">{sub}</p>}
    </div>
  );
}

export default function Dashboard() {
  const [data, setData]     = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/dashboard/stats')
      .then(r => setData(r.data.data))
      .catch(() => toast.error('Failed to load dashboard'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="flex items-center justify-center h-64 text-slate-400">Loading dashboard...</div>;
  if (!data)   return null;

  const monthlyArr = Array(12).fill(0);
  (data.monthlyIncome || []).forEach(m => { monthlyArr[m.month - 1] = Number(m.total); });

  const barData = {
    labels: MONTHS,
    datasets: [{
      label: 'Income (₹)',
      data: monthlyArr,
      backgroundColor: monthlyArr.map((_, i) => i === new Date().getMonth() ? '#6366f1' : 'rgba(99,102,241,0.35)'),
      borderRadius: 6,
    }],
  };

  const doughnutData = {
    labels: ['Paid', 'Pending', 'Overdue'],
    datasets: [{
      data: [data.paidCount, data.pendingCount - Math.max(0, data.pendingCount - data.paidCount), 3],
      backgroundColor: ['#10b981','#f59e0b','#ef4444'],
      borderWidth: 0,
    }],
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-bold text-white">Dashboard Overview</h1>
        <p className="text-slate-400 text-sm mt-1">Welcome back! Here's what's happening today.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Students"    value={data.totalStudents}   sub={`${data.activeStudents} active`}                      icon="👥" color="bg-primary-500/15" />
        <StatCard label="Paid This Month"   value={data.paidCount}       sub={`₹${Number(data.monthlyCollection).toLocaleString('en-IN')}`} icon="✅" color="bg-green-500/15" />
        <StatCard label="Pending Dues"      value={data.pendingCount}    sub={`₹${Number(data.pendingAmount).toLocaleString('en-IN')} due`}  icon="⏳" color="bg-amber-500/15" />
        <StatCard label="Empty Seats"       value={data.emptySeats}      sub={`${data.occupiedSeats} occupied`}                    icon="💺" color="bg-cyan-500/15" />
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Today's Collection" value={`₹${Number(data.todayCollection||0).toLocaleString('en-IN')}`} sub="today" icon="💰" color="bg-teal-500/15" />
        <StatCard label="Present Today"      value={data.presentToday}   sub="checked in"                          icon="📋" color="bg-indigo-500/15" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <div className="lg:col-span-2 bg-dark-600 border border-white/5 rounded-2xl p-5">
          <h3 className="text-sm font-semibold text-white mb-4">Monthly Income {new Date().getFullYear()}</h3>
          <Bar data={barData} options={{
            responsive: true, plugins: { legend: { display: false } },
            scales: {
              x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 10 } } },
              y: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#64748b', font: { size: 10 }, callback: v => `₹${(v/1000).toFixed(0)}K` } },
            },
          }} />
        </div>
        <div className="bg-dark-600 border border-white/5 rounded-2xl p-5">
          <h3 className="text-sm font-semibold text-white mb-4">Fee Status</h3>
          <Doughnut data={doughnutData} options={{
            responsive: true, cutout: '70%',
            plugins: { legend: { position: 'bottom', labels: { color: '#94a3b8', font: { size: 11 }, padding: 12, boxWidth: 12 } } },
          }} />
        </div>
      </div>

      {/* Recent Payments */}
      <div className="bg-dark-600 border border-white/5 rounded-2xl p-5">
        <h3 className="text-sm font-semibold text-white mb-4">Recent Payments</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left">
                <th className="text-xs text-slate-500 font-semibold uppercase tracking-wider pb-3">Student</th>
                <th className="text-xs text-slate-500 font-semibold uppercase tracking-wider pb-3">Seat</th>
                <th className="text-xs text-slate-500 font-semibold uppercase tracking-wider pb-3">Month</th>
                <th className="text-xs text-slate-500 font-semibold uppercase tracking-wider pb-3">Amount</th>
                <th className="text-xs text-slate-500 font-semibold uppercase tracking-wider pb-3">Date</th>
              </tr>
            </thead>
            <tbody>
              {(data.recentPayments || []).map((p, i) => (
                <tr key={i} className="border-t border-white/5 hover:bg-white/2">
                  <td className="py-3 text-white font-medium">{p.student_name}</td>
                  <td className="py-3"><span className="bg-primary-500/20 text-primary-300 px-2 py-0.5 rounded-md text-xs font-semibold">{p.seat_number || '—'}</span></td>
                  <td className="py-3 text-slate-400">{MONTHS[(p.month||1)-1]} {p.year}</td>
                  <td className="py-3 text-green-400 font-semibold">₹{Number(p.fee_amount).toLocaleString('en-IN')}</td>
                  <td className="py-3 text-slate-400">{p.payment_date ? new Date(p.payment_date).toLocaleDateString('en-IN') : '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
