import React, { useEffect, useState } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

const MONTHS = ['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

export default function Receipts() {
  const [fees, setFees]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    api.get('/fees', { params: { status: 'paid', limit: 100 } })
      .then(r => setFees(r.data.data))
      .catch(() => toast.error('Failed to load receipts'))
      .finally(() => setLoading(false));
  }, []);

  const filtered = fees.filter(f =>
    !search || f.student_name?.toLowerCase().includes(search.toLowerCase()) ||
    f.receipt_number?.includes(search) || String(f.month).includes(search)
  );

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-bold text-white">Payment Receipts</h1>
        <p className="text-slate-400 text-sm">Download and print payment receipts</p>
      </div>

      <div className="mb-4">
        <input type="text" placeholder="Search by student name or receipt number..."
          value={search} onChange={e => setSearch(e.target.value)}
          className="bg-dark-600 border border-white/10 rounded-xl px-4 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-primary-500 w-full max-w-md" />
      </div>

      <div className="bg-dark-600 border border-white/5 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5">
                {['Receipt No.','Student','Seat','Month/Year','Amount','Mode','Date','Action'].map(h => (
                  <th key={h} className="text-left text-[10px] font-bold uppercase tracking-wider text-slate-500 px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={8} className="text-center py-12 text-slate-500">Loading...</td></tr>
              ) : filtered.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-12 text-slate-500">No paid receipts found</td></tr>
              ) : filtered.map(f => (
                <tr key={f.id} className="border-t border-white/[0.04] hover:bg-white/[0.02] transition">
                  <td className="px-4 py-3 text-primary-400 font-mono text-xs">{f.receipt_number}</td>
                  <td className="px-4 py-3 text-white font-medium">{f.student_name}</td>
                  <td className="px-4 py-3"><span className="bg-primary-500/15 text-primary-300 px-2 py-0.5 rounded-md text-xs font-bold">{f.seat_number||'—'}</span></td>
                  <td className="px-4 py-3 text-slate-400 text-xs">{MONTHS[f.month]} {f.year}</td>
                  <td className="px-4 py-3 text-green-400 font-semibold">₹{Number(f.fee_amount).toLocaleString('en-IN')}</td>
                  <td className="px-4 py-3 text-slate-400 text-xs capitalize">{f.payment_mode}</td>
                  <td className="px-4 py-3 text-slate-400 text-xs">{f.payment_date ? new Date(f.payment_date).toLocaleDateString('en-IN') : '—'}</td>
                  <td className="px-4 py-3">
                    <button onClick={() => window.open(`/api/fees/receipt/${f.receipt_number}`, '_blank')}
                      className="bg-primary-500/15 hover:bg-primary-500/25 text-primary-400 px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5">
                      📄 PDF
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
