import React, { useEffect, useState } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function Attendance() {
  const today = new Date();
  const [records, setRecords]   = useState([]);
  const [stats, setStats]       = useState(null);
  const [students, setStudents] = useState([]);
  const [selStudent, setSelStudent] = useState('');
  const [filterDate, setFilterDate] = useState(today.toISOString().split('T')[0]);
  const [loading, setLoading]   = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const [recRes, statsRes, stuRes] = await Promise.all([
        api.get('/attendance', { params: { date: filterDate } }),
        api.get('/attendance/stats'),
        api.get('/students', { params: { status: 'active', limit: 200 } }),
      ]);
      setRecords(recRes.data.data);
      setStats(statsRes.data.data);
      setStudents(stuRes.data.data);
    } catch { toast.error('Failed to load attendance'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [filterDate]);

  const checkIn = async () => {
    if (!selStudent) return toast.error('Select a student first');
    try {
      await api.post('/attendance/checkin', { student_id: selStudent });
      toast.success('✅ Check-in recorded!');
      load();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
  };

  const checkOut = async () => {
    if (!selStudent) return toast.error('Select a student first');
    try {
      await api.post('/attendance/checkout', { student_id: selStudent });
      toast.success('👋 Check-out recorded!');
      load();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
  };

  // Build calendar for current month
  const year = today.getFullYear(), month = today.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDay = new Date(year, month, 1).getDay();
  const dayNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-bold text-white">Attendance</h1>
        <p className="text-slate-400 text-sm">Track daily student presence</p>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-dark-600 border border-white/5 rounded-2xl p-4 text-center">
            <p className="text-3xl font-bold text-green-400">{stats.present}</p>
            <p className="text-xs text-slate-500 mt-1">Present Today</p>
          </div>
          <div className="bg-dark-600 border border-white/5 rounded-2xl p-4 text-center">
            <p className="text-3xl font-bold text-red-400">{stats.absent}</p>
            <p className="text-xs text-slate-500 mt-1">Absent Today</p>
          </div>
          <div className="bg-dark-600 border border-white/5 rounded-2xl p-4 text-center">
            <p className="text-3xl font-bold text-primary-400">
              {stats.total > 0 ? Math.round(stats.present / stats.total * 100) : 0}%
            </p>
            <p className="text-xs text-slate-500 mt-1">Attendance Rate</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Check In/Out Panel */}
        <div className="bg-dark-600 border border-white/5 rounded-2xl p-5">
          <h3 className="text-sm font-semibold text-white mb-4">Mark Attendance</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-xs text-slate-400 font-medium mb-1.5">Select Student</label>
              <select value={selStudent} onChange={e => setSelStudent(e.target.value)}
                className="w-full bg-dark-700 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500">
                <option value="">Choose a student...</option>
                {students.map(s => <option key={s.id} value={s.id}>{s.name} — {s.seat_number || 'No seat'}</option>)}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button onClick={checkIn} className="bg-green-500 hover:bg-green-600 text-white py-3 rounded-xl text-sm font-semibold transition flex items-center justify-center gap-2">
                🟢 Check In
              </button>
              <button onClick={checkOut} className="bg-dark-700 border border-white/10 hover:border-white/20 text-slate-300 hover:text-white py-3 rounded-xl text-sm font-semibold transition flex items-center justify-center gap-2">
                🔴 Check Out
              </button>
            </div>
          </div>

          <div className="mt-5">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Filter by Date</h4>
              <input type="date" value={filterDate} onChange={e => setFilterDate(e.target.value)}
                className="bg-dark-700 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-primary-500" />
            </div>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {loading ? (
                <p className="text-center text-slate-500 py-4 text-sm">Loading...</p>
              ) : records.length === 0 ? (
                <p className="text-center text-slate-500 py-4 text-sm">No records for this date</p>
              ) : records.map(r => (
                <div key={r.id} className="flex items-center gap-3 bg-dark-700 rounded-xl px-3 py-2.5">
                  <div className={`w-2 h-2 rounded-full flex-shrink-0 ${r.status === 'present' ? 'bg-green-400' : 'bg-red-400'}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white font-medium truncate">{r.student_name}</p>
                    <p className="text-[10px] text-slate-500">Seat {r.seat_number || '—'}</p>
                  </div>
                  <div className="text-right text-[10px] text-slate-400">
                    <p>In: {r.check_in || '—'}</p>
                    <p>Out: {r.check_out || '—'}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Calendar */}
        <div className="bg-dark-600 border border-white/5 rounded-2xl p-5">
          <h3 className="text-sm font-semibold text-white mb-4">
            {today.toLocaleString('default', { month: 'long' })} {year}
          </h3>
          <div className="grid grid-cols-7 gap-1 mb-2">
            {dayNames.map(d => (
              <div key={d} className="text-center text-[9px] font-bold text-slate-500 uppercase py-1">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {Array(firstDay).fill(null).map((_, i) => <div key={`e${i}`} />)}
            {Array(daysInMonth).fill(null).map((_, i) => {
              const day = i + 1;
              const isToday = day === today.getDate();
              const isPast  = day < today.getDate();
              return (
                <div key={day}
                  className={`aspect-square rounded-lg flex items-center justify-center text-xs font-semibold transition-all ${
                    isToday  ? 'bg-primary-500 text-white' :
                    isPast   ? 'bg-green-500/15 text-green-400 cursor-pointer hover:bg-green-500/25' :
                    'bg-dark-700 text-slate-600'
                  }`}
                >{day}</div>
              );
            })}
          </div>
          <div className="flex gap-4 mt-4">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <div className="w-3 h-3 rounded-sm bg-green-500/30" /> Past Days
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <div className="w-3 h-3 rounded-sm bg-primary-500" /> Today
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
