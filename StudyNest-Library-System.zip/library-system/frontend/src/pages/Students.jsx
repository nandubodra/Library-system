import React, { useEffect, useState, useCallback } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

const TIMINGS = { morning: 'Morning', evening: 'Evening', full_day: 'Full Day' };
const EMPTY = {
  name:'', father_name:'', mobile:'', email:'', address:'', college:'',
  course:'', aadhaar:'', seat_id:'', joining_date:'', monthly_fee:'1500',
  security_deposit:'2000', library_timing:'full_day', status:'active'
};

function Badge({ status }) {
  return status === 'active'
    ? <span className="bg-green-500/15 text-green-400 px-2 py-0.5 rounded-full text-[10px] font-bold">Active</span>
    : <span className="bg-slate-500/15 text-slate-400 px-2 py-0.5 rounded-full text-[10px] font-bold">Inactive</span>;
}

export default function Students() {
  const [students, setStudents] = useState([]);
  const [seats, setSeats]       = useState([]);
  const [total, setTotal]       = useState(0);
  const [page, setPage]         = useState(1);
  const [search, setSearch]     = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [loading, setLoading]   = useState(true);
  const [modal, setModal]       = useState(false);
  const [form, setForm]         = useState(EMPTY);
  const [editId, setEditId]     = useState(null);
  const [photo, setPhoto]       = useState(null);
  const [saving, setSaving]     = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: 15, search, status: filterStatus };
      const { data } = await api.get('/students', { params });
      setStudents(data.data);
      setTotal(data.total);
    } catch { toast.error('Failed to load students'); }
    finally { setLoading(false); }
  }, [page, search, filterStatus]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    api.get('/seats').then(r => setSeats(r.data.data.filter(s => s.status === 'available' || (editId && s.student_id))));
  }, [modal, editId]);

  const openAdd = () => { setForm(EMPTY); setEditId(null); setPhoto(null); setModal(true); };
  const openEdit = s => {
    setForm({ ...s, seat_id: s.seat_id || '' });
    setEditId(s.id); setPhoto(null); setModal(true);
  };

  const handleSave = async e => {
    e.preventDefault();
    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => fd.append(k, v));
      if (photo) fd.append('photo', photo);

      if (editId) {
        await api.put(`/students/${editId}`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        toast.success('Student updated!');
      } else {
        await api.post('/students', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
        toast.success('Student added!');
      }
      setModal(false); load();
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to save'); }
    finally { setSaving(false); }
  };

  const handleDelete = async id => {
    if (!window.confirm('Delete this student? This cannot be undone.')) return;
    try {
      await api.delete(`/students/${id}`);
      toast.success('Student deleted');
      load();
    } catch { toast.error('Failed to delete'); }
  };

  const colors = ['#6366f1','#06b6d4','#10b981','#f59e0b','#8b5cf6','#ec4899'];
  const initials = name => name?.split(' ').map(w => w[0]).join('').toUpperCase().slice(0,2);

  const totalPages = Math.ceil(total / 15);

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-white">Students</h1>
          <p className="text-slate-400 text-sm">{total} total students</p>
        </div>
        <button onClick={openAdd} className="bg-primary-500 hover:bg-primary-600 text-white px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 transition">
          <span className="text-lg leading-none">+</span> Add Student
        </button>
      </div>

      {/* Filters */}
      <div className="flex gap-3 mb-4 flex-wrap">
        <input
          type="text" placeholder="Search name, mobile, college, seat..."
          value={search} onChange={e => { setSearch(e.target.value); setPage(1); }}
          className="bg-dark-600 border border-white/10 rounded-xl px-4 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-primary-500 flex-1 min-w-48"
        />
        <select value={filterStatus} onChange={e => { setFilterStatus(e.target.value); setPage(1); }}
          className="bg-dark-600 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-primary-500">
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-dark-600 border border-white/5 rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5">
                {['Student','Seat','Mobile','Course','Fee','Timing','Status','Actions'].map(h => (
                  <th key={h} className="text-left text-[10px] font-bold uppercase tracking-wider text-slate-500 px-4 py-3">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={8} className="text-center py-12 text-slate-500">Loading...</td></tr>
              ) : students.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-12 text-slate-500">No students found</td></tr>
              ) : students.map((s, i) => (
                <tr key={s.id} className="border-t border-white/[0.04] hover:bg-white/[0.02] transition">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      {s.photo_url
                        ? <img src={s.photo_url} alt="" className="w-8 h-8 rounded-lg object-cover" />
                        : <div className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold text-white flex-shrink-0"
                            style={{ background: `${colors[i % colors.length]}33`, color: colors[i % colors.length] }}>
                            {initials(s.name)}
                          </div>
                      }
                      <div>
                        <p className="text-white font-medium">{s.name}</p>
                        <p className="text-slate-500 text-[10px]">{s.father_name}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="bg-primary-500/15 text-primary-300 px-2 py-0.5 rounded-md text-xs font-bold">{s.seat_number || '—'}</span>
                  </td>
                  <td className="px-4 py-3 text-slate-300">{s.mobile}</td>
                  <td className="px-4 py-3 text-slate-400 text-xs">{s.course || '—'}</td>
                  <td className="px-4 py-3 text-green-400 font-semibold">₹{Number(s.monthly_fee).toLocaleString('en-IN')}</td>
                  <td className="px-4 py-3 text-slate-400 text-xs">{TIMINGS[s.library_timing]}</td>
                  <td className="px-4 py-3"><Badge status={s.status} /></td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1.5">
                      <button onClick={() => openEdit(s)}
                        className="w-7 h-7 rounded-lg bg-dark-700 border border-white/10 flex items-center justify-center text-slate-400 hover:text-primary-300 hover:border-primary-500/40 transition text-xs">✏️</button>
                      <button onClick={() => handleDelete(s.id)}
                        className="w-7 h-7 rounded-lg bg-dark-700 border border-white/10 flex items-center justify-center text-slate-400 hover:text-red-400 hover:border-red-500/40 transition text-xs">🗑️</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-white/5">
            <p className="text-xs text-slate-500">Page {page} of {totalPages}</p>
            <div className="flex gap-2">
              <button disabled={page === 1} onClick={() => setPage(p => p - 1)}
                className="px-3 py-1 rounded-lg bg-dark-700 border border-white/10 text-xs text-slate-400 hover:text-white disabled:opacity-40 transition">← Prev</button>
              <button disabled={page === totalPages} onClick={() => setPage(p => p + 1)}
                className="px-3 py-1 rounded-lg bg-dark-700 border border-white/10 text-xs text-slate-400 hover:text-white disabled:opacity-40 transition">Next →</button>
            </div>
          </div>
        )}
      </div>

      {/* Modal */}
      {modal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-dark-700 border border-white/10 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
              <h2 className="text-base font-bold text-white">{editId ? 'Edit Student' : 'Add New Student'}</h2>
              <button onClick={() => setModal(false)} className="text-slate-400 hover:text-white text-xl">×</button>
            </div>
            <form onSubmit={handleSave} className="p-6">
              <div className="grid grid-cols-2 gap-4">
                {[
                  ['name','Full Name','text',true],
                  ['father_name',"Father's Name",'text',false],
                  ['mobile','Mobile Number','tel',true],
                  ['email','Email','email',false],
                  ['college','College / Institution','text',false],
                  ['course','Course','text',false],
                  ['aadhaar','Aadhaar (Optional)','text',false],
                  ['joining_date','Joining Date','date',true],
                  ['monthly_fee','Monthly Fee (₹)','number',true],
                  ['security_deposit','Security Deposit (₹)','number',false],
                ].map(([key, label, type, required]) => (
                  <div key={key}>
                    <label className="block text-xs text-slate-400 font-medium mb-1.5">{label}{required && ' *'}</label>
                    <input type={type} required={required} value={form[key] || ''}
                      onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))}
                      className="w-full bg-dark-800 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500 transition" />
                  </div>
                ))}
                <div>
                  <label className="block text-xs text-slate-400 font-medium mb-1.5">Seat</label>
                  <select value={form.seat_id} onChange={e => setForm(p => ({ ...p, seat_id: e.target.value }))}
                    className="w-full bg-dark-800 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500">
                    <option value="">No Seat</option>
                    {seats.map(s => <option key={s.id} value={s.id}>{s.seat_number} — {s.status}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-slate-400 font-medium mb-1.5">Library Timing</label>
                  <select value={form.library_timing} onChange={e => setForm(p => ({ ...p, library_timing: e.target.value }))}
                    className="w-full bg-dark-800 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500">
                    <option value="morning">Morning (6AM–1PM)</option>
                    <option value="evening">Evening (2PM–9PM)</option>
                    <option value="full_day">Full Day (6AM–9PM)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs text-slate-400 font-medium mb-1.5">Status</label>
                  <select value={form.status} onChange={e => setForm(p => ({ ...p, status: e.target.value }))}
                    className="w-full bg-dark-800 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500">
                    <option value="active">Active</option>
                    <option value="inactive">Inactive</option>
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="block text-xs text-slate-400 font-medium mb-1.5">Address</label>
                  <textarea value={form.address || ''} onChange={e => setForm(p => ({ ...p, address: e.target.value }))} rows={2}
                    className="w-full bg-dark-800 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500 resize-none" />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs text-slate-400 font-medium mb-1.5">Photo</label>
                  <input type="file" accept="image/*" onChange={e => setPhoto(e.target.files[0])}
                    className="text-sm text-slate-400 file:mr-3 file:bg-dark-600 file:border file:border-white/10 file:rounded-lg file:px-3 file:py-1.5 file:text-xs file:text-slate-300 file:cursor-pointer" />
                </div>
              </div>
              <div className="flex gap-3 mt-6 justify-end">
                <button type="button" onClick={() => setModal(false)}
                  className="px-5 py-2 rounded-xl bg-dark-800 border border-white/10 text-sm text-slate-300 hover:text-white transition">Cancel</button>
                <button type="submit" disabled={saving}
                  className="px-5 py-2 rounded-xl bg-primary-500 hover:bg-primary-600 text-white text-sm font-semibold transition flex items-center gap-2">
                  {saving ? '⏳ Saving...' : editId ? '✅ Update Student' : '✅ Add Student'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
