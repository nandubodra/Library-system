import React, { useEffect, useState } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

export default function Settings() {
  const [form, setForm]       = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving]   = useState(false);
  const [logo, setLogo]       = useState(null);
  const [pwForm, setPwForm]   = useState({ currentPassword:'', newPassword:'', confirm:'' });
  const [changingPw, setChangingPw] = useState(false);

  useEffect(() => {
    api.get('/settings').then(r => setForm(r.data.data || {})).finally(() => setLoading(false));
  }, []);

  const handleSave = async e => {
    e.preventDefault();
    setSaving(true);
    try {
      const fd = new FormData();
      Object.entries(form).forEach(([k, v]) => v != null && fd.append(k, v));
      if (logo) fd.append('logo', logo);
      await api.put('/settings', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success('Settings saved!');
    } catch { toast.error('Failed to save settings'); }
    finally { setSaving(false); }
  };

  const handlePwChange = async e => {
    e.preventDefault();
    if (pwForm.newPassword !== pwForm.confirm) return toast.error('Passwords do not match');
    setChangingPw(true);
    try {
      await api.post('/auth/change-password', pwForm);
      toast.success('Password changed!');
      setPwForm({ currentPassword:'', newPassword:'', confirm:'' });
    } catch (err) { toast.error(err.response?.data?.message || 'Failed'); }
    finally { setChangingPw(false); }
  };

  const set = (k, v) => setForm(p => ({ ...p, [k]: v }));

  if (loading) return <div className="flex items-center justify-center h-64 text-slate-400">Loading...</div>;

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-bold text-white">Settings</h1>
        <p className="text-slate-400 text-sm">Configure your library management system</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Library Info */}
        <form onSubmit={handleSave} className="bg-dark-600 border border-white/5 rounded-2xl p-5">
          <h3 className="text-sm font-semibold text-white mb-4">Library Information</h3>
          <div className="space-y-3">
            {[
              ['library_name','Library Name'],
              ['phone','Phone Number'],
              ['email','Email Address'],
              ['upi_id','UPI ID'],
            ].map(([k, lbl]) => (
              <div key={k}>
                <label className="block text-xs text-slate-400 font-medium mb-1">{lbl}</label>
                <input type="text" value={form[k] || ''} onChange={e => set(k, e.target.value)}
                  className="w-full bg-dark-700 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500 transition" />
              </div>
            ))}
            <div>
              <label className="block text-xs text-slate-400 font-medium mb-1">Address</label>
              <textarea value={form.address || ''} onChange={e => set('address', e.target.value)} rows={2}
                className="w-full bg-dark-700 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500 resize-none" />
            </div>
            <div>
              <label className="block text-xs text-slate-400 font-medium mb-1">Library Logo</label>
              <input type="file" accept="image/*" onChange={e => setLogo(e.target.files[0])}
                className="text-xs text-slate-400 file:mr-3 file:bg-dark-700 file:border file:border-white/10 file:rounded-lg file:px-3 file:py-1.5 file:text-xs file:text-slate-300 file:cursor-pointer" />
            </div>
          </div>
          <button type="submit" disabled={saving} className="mt-4 w-full bg-primary-500 hover:bg-primary-600 text-white py-2.5 rounded-xl text-sm font-semibold transition">
            {saving ? '⏳ Saving...' : '💾 Save Library Info'}
          </button>
        </form>

        {/* Fee Config */}
        <div className="bg-dark-600 border border-white/5 rounded-2xl p-5">
          <h3 className="text-sm font-semibold text-white mb-4">Fee Configuration</h3>
          <div className="space-y-3">
            {[
              ['default_fee','Default Monthly Fee (₹)','number'],
              ['security_deposit','Security Deposit (₹)','number'],
              ['late_charge_per_day','Late Charge per Day (₹)','number'],
              ['total_seats','Total Seats','number'],
            ].map(([k, lbl, type]) => (
              <div key={k}>
                <label className="block text-xs text-slate-400 font-medium mb-1">{lbl}</label>
                <input type={type} value={form[k] || ''} onChange={e => set(k, e.target.value)}
                  className="w-full bg-dark-700 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500 transition" />
              </div>
            ))}
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            {[
              ['morning_start','Morning Start','time'],
              ['morning_end','Morning End','time'],
              ['evening_start','Evening Start','time'],
              ['evening_end','Evening End','time'],
            ].map(([k, lbl, type]) => (
              <div key={k}>
                <label className="block text-xs text-slate-400 font-medium mb-1">{lbl}</label>
                <input type={type} value={form[k] || ''} onChange={e => set(k, e.target.value)}
                  className="w-full bg-dark-700 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500 transition" />
              </div>
            ))}
          </div>
        </div>

        {/* Change Password */}
        <form onSubmit={handlePwChange} className="bg-dark-600 border border-white/5 rounded-2xl p-5">
          <h3 className="text-sm font-semibold text-white mb-4">Change Password</h3>
          <div className="space-y-3">
            {[
              ['currentPassword','Current Password'],
              ['newPassword','New Password'],
              ['confirm','Confirm New Password'],
            ].map(([k, lbl]) => (
              <div key={k}>
                <label className="block text-xs text-slate-400 font-medium mb-1">{lbl}</label>
                <input type="password" required value={pwForm[k]} onChange={e => setPwForm(p => ({ ...p, [k]: e.target.value }))}
                  className="w-full bg-dark-700 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-primary-500 transition" />
              </div>
            ))}
          </div>
          <button type="submit" disabled={changingPw} className="mt-4 w-full bg-dark-700 border border-white/10 hover:border-primary-500/40 text-white py-2.5 rounded-xl text-sm font-semibold transition">
            {changingPw ? '⏳ Changing...' : '🔐 Change Password'}
          </button>
        </form>

        {/* System */}
        <div className="bg-dark-600 border border-white/5 rounded-2xl p-5">
          <h3 className="text-sm font-semibold text-white mb-4">System</h3>
          <div className="space-y-3">
            {[
              { label: '📤 Export All Data (Excel)', action: () => toast('Coming soon!', { icon: '🛠️' }) },
              { label: '🗄️ Backup Database', action: () => toast('Contact your system admin to backup the MySQL database.') },
              { label: '🔄 Generate This Month\'s Fees', action: async () => {
                const now = new Date();
                await api.post('/fees/generate-monthly', { month: now.getMonth()+1, year: now.getFullYear() });
                toast.success('Fees generated!');
              }},
            ].map(({ label, action }) => (
              <button key={label} onClick={action}
                className="w-full bg-dark-700 border border-white/10 hover:border-white/20 text-slate-300 hover:text-white py-2.5 px-4 rounded-xl text-sm text-left transition">
                {label}
              </button>
            ))}
            <div className="pt-2 border-t border-white/5">
              <p className="text-xs text-slate-600 text-center">StudyNest v1.0.0 • Built for personal libraries</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
