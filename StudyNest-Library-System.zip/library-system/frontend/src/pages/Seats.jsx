import React, { useEffect, useState } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';

const STATUS_STYLE = {
  occupied:  'bg-green-500/15 border-green-500/40 text-green-400',
  available: 'bg-dark-700 border-white/10 text-slate-500 hover:border-primary-500/40 hover:text-slate-300',
  reserved:  'bg-red-500/10 border-red-500/35 text-red-400',
};

export default function Seats() {
  const [seats, setSeats]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState(null);

  const load = async () => {
    try {
      const { data } = await api.get('/seats');
      setSeats(data.data);
    } catch { toast.error('Failed to load seats'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, []);

  const rows = ['A','B','C','D','E'];
  const grouped = rows.reduce((acc, r) => {
    acc[r] = seats.filter(s => s.row_label === r);
    return acc;
  }, {});

  const updateStatus = async (id, status) => {
    try {
      await api.put(`/seats/${id}`, { status });
      toast.success('Seat updated');
      setSelected(null);
      load();
    } catch { toast.error('Failed to update seat'); }
  };

  const occupied  = seats.filter(s => s.status === 'occupied').length;
  const available = seats.filter(s => s.status === 'available').length;
  const reserved  = seats.filter(s => s.status === 'reserved').length;

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-xl font-bold text-white">Seat Layout</h1>
        <p className="text-slate-400 text-sm">Visual map of all library seats</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="bg-dark-600 border border-white/5 rounded-2xl p-4 flex items-center gap-3">
          <div className="w-3 h-3 rounded-sm bg-green-500/60 flex-shrink-0" />
          <div>
            <p className="text-2xl font-bold text-green-400">{occupied}</p>
            <p className="text-xs text-slate-500">Occupied</p>
          </div>
        </div>
        <div className="bg-dark-600 border border-white/5 rounded-2xl p-4 flex items-center gap-3">
          <div className="w-3 h-3 rounded-sm bg-white/20 border border-white/20 flex-shrink-0" />
          <div>
            <p className="text-2xl font-bold text-white">{available}</p>
            <p className="text-xs text-slate-500">Available</p>
          </div>
        </div>
        <div className="bg-dark-600 border border-white/5 rounded-2xl p-4 flex items-center gap-3">
          <div className="w-3 h-3 rounded-sm bg-red-500/40 flex-shrink-0" />
          <div>
            <p className="text-2xl font-bold text-red-400">{reserved}</p>
            <p className="text-xs text-slate-500">Reserved</p>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-slate-500">Loading seat map...</div>
      ) : (
        <div className="bg-dark-600 border border-white/5 rounded-2xl p-6">
          {/* Legend */}
          <div className="flex gap-5 mb-6">
            {[['bg-green-500/40','Occupied'],['bg-dark-700 border border-white/15','Available'],['bg-red-500/30','Reserved']].map(([cls,lbl]) => (
              <div key={lbl} className="flex items-center gap-2">
                <div className={`w-5 h-5 rounded-md ${cls}`} />
                <span className="text-xs text-slate-400">{lbl}</span>
              </div>
            ))}
          </div>

          {/* Seat Grid */}
          {rows.map(row => (
            <div key={row} className="mb-5">
              <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Row {row}</p>
              <div className="flex gap-2 flex-wrap">
                {grouped[row]?.map(seat => (
                  <button
                    key={seat.id}
                    onClick={() => setSelected(seat)}
                    className={`w-16 h-14 rounded-xl border text-xs font-bold transition-all duration-150 flex flex-col items-center justify-center gap-0.5 ${STATUS_STYLE[seat.status]}`}
                  >
                    <span>{seat.seat_number}</span>
                    {seat.student_name && <span className="text-[9px] font-normal truncate w-14 text-center px-1 opacity-80">{seat.student_name.split(' ')[0]}</span>}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Seat Detail Modal */}
      {selected && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-dark-700 border border-white/10 rounded-2xl w-80">
            <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
              <h3 className="font-bold text-white">Seat {selected.seat_number}</h3>
              <button onClick={() => setSelected(null)} className="text-slate-400 hover:text-white">×</button>
            </div>
            <div className="p-5">
              <div className="mb-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-slate-400">Status</span>
                  <span className={`font-semibold capitalize ${selected.status === 'occupied' ? 'text-green-400' : selected.status === 'reserved' ? 'text-red-400' : 'text-slate-300'}`}>{selected.status}</span>
                </div>
                {selected.student_name && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Student</span>
                    <span className="text-white font-medium">{selected.student_name}</span>
                  </div>
                )}
              </div>
              <p className="text-xs text-slate-500 mb-3">Change seat status:</p>
              <div className="grid grid-cols-3 gap-2">
                {['available','occupied','reserved'].map(s => (
                  <button key={s} onClick={() => updateStatus(selected.id, s)}
                    className={`py-2 rounded-xl text-xs font-semibold capitalize transition ${
                      selected.status === s
                        ? 'bg-primary-500 text-white'
                        : 'bg-dark-800 border border-white/10 text-slate-400 hover:text-white'
                    }`}>{s}</button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
