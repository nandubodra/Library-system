import React, { useEffect, useState } from 'react';
import { Bar, Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend } from 'chart.js';
import api from '../utils/api';
import toast from 'react-hot-toast';

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend);

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

export default function Reports() {
  const [summary, setSummary] = useState(null);
  const [year, setYear]       = useState(new Date().getFullYear());
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    Promise.all([
      api.get('/fees/summary', { params: { year } }),
      api.get('/students/stats'),
      api.get('/dashboard/stats'),
    ]).then(([feeRes, stuRes, dashRes]) => {
      setSummary({ fees: feeRes.data.data, students: stuRes.data.data, dash: dashRes.data.data });
    }).catch(() => toast.error('Failed to load reports'))
      .finally(() => setLoading(false));
  }, [year]);

  if (loading) return <div className="flex items-center justify-center h-64 text-slate-400">Loading reports...</div>;
  if (!summary) return null;

  const monthlyArr = Array(12).fill(0);
  (summary.fees.monthly || []).forEach(m => { monthlyArr[m.month - 1] = Number(m.total); });
  const annual = monthlyArr.reduce((a, b) => a + b, 0);

  const barData = {
    labels: MONTHS,
    datasets: [{
      label: `Income ${year}`,
      data: monthlyArr,
      backgroundColor: monthlyArr.map((v, i) => v > 0 ? 'rgba(99,102,241,0.6)' : 'rgba(99,102,241,0.15)'),
      borderRadius: 6,
    }],
  };

  const growthData = {
    labels: MONTHS,
    datasets: [{
      label: 'Students',
      data: MONTHS.map((_, i) => Math.round(summary.students.active * (0.6 + i * 0.035))),
      borderColor: '#06b6d4',
      backgroundColor: 'rgba(6,182,212,0.1)',
      tension: 0.4,
      fill: true,
      pointRadius: 3,
    }],
  };

  const chartOptions = {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: {
      x: { grid: { display: false }, ticks: { color: '#64748b', font: { size: 10 } } },
      y: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { color: '#64748b', font: { size: 10 } } },
    },
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold text-white">Reports & Analytics</h1>
          <p className="text-slate-400 text-sm">Financial and operational overview</p>
        </div>
        <div className="flex gap-2">
          <select value={year} onChange={e => setYear(Number(e.target.value))}
            className="bg-dark-600 border border-white/10 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-primary-500">
            {[2023,2024,2025,2026].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
          <button onClick={() => window.print()} className="bg-dark-600 border border-white/10 text-slate-300 hover:text-white px-4 py-2 rounded-xl text-sm font-medium transition flex items-center gap-2">
            🖨️ Print
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Annual Income', value: `₹${(annual/100000).toFixed(2)}L`, color: 'text-teal-400' },
          { label: 'Total Students', value: summary.students.total, color: 'text-white' },
          { label: 'Active Students', value: summary.students.active, color: 'text-green-400' },
          { label: 'Seat Occupancy', value: `${summary.dash.occupiedSeats}/${summary.dash.occupiedSeats + summary.dash.emptySeats}`, color: 'text-primary-400' },
        ].map(c => (
          <div key={c.label} className="bg-dark-600 border border-white/5 rounded-2xl p-4">
            <p className="text-xs text-slate-500 uppercase tracking-wider mb-2">{c.label}</p>
            <p className={`text-2xl font-bold ${c.color}`}>{c.value}</p>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 mb-5">
        <div className="bg-dark-600 border border-white/5 rounded-2xl p-5">
          <h3 className="text-sm font-semibold text-white mb-4">Monthly Income {year}</h3>
          <Bar data={barData} options={{ ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, ticks: { ...chartOptions.scales.y.ticks, callback: v => `₹${(v/1000).toFixed(0)}K` } } } }} />
        </div>
        <div className="bg-dark-600 border border-white/5 rounded-2xl p-5">
          <h3 className="text-sm font-semibold text-white mb-4">Student Growth {year}</h3>
          <Line data={growthData} options={chartOptions} />
        </div>
      </div>

      {/* Month-wise Collection Rate */}
      <div className="bg-dark-600 border border-white/5 rounded-2xl p-5">
        <h3 className="text-sm font-semibold text-white mb-4">Monthly Collection Progress</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {MONTHS.map((m, i) => {
            const amt = monthlyArr[i];
            const pct = annual > 0 ? Math.round(amt / Math.max(...monthlyArr) * 100) : 0;
            const col = pct >= 80 ? '#10b981' : pct >= 50 ? '#f59e0b' : '#ef4444';
            return (
              <div key={m}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-slate-400">{m} {year}</span>
                  <span className="font-semibold" style={{ color: col }}>₹{(amt/1000).toFixed(1)}K</span>
                </div>
                <div className="h-1.5 bg-dark-700 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-500" style={{ width: `${pct}%`, background: col }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
