import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import toast from 'react-hot-toast';

const NAV = [
  { group: 'Main',
    items: [
      { to: '/dashboard',  icon: '⊞', label: 'Dashboard' },
      { to: '/students',   icon: '👥', label: 'Students' },
      { to: '/seats',      icon: '💺', label: 'Seat Layout' },
    ]
  },
  { group: 'Finance',
    items: [
      { to: '/fees',       icon: '💳', label: 'Fee Tracking' },
      { to: '/receipts',   icon: '🧾', label: 'Receipts' },
    ]
  },
  { group: 'Operations',
    items: [
      { to: '/attendance', icon: '✅', label: 'Attendance' },
      { to: '/reports',    icon: '📊', label: 'Reports' },
    ]
  },
  { group: 'System',
    items: [
      { to: '/settings',   icon: '⚙️', label: 'Settings' },
    ]
  },
];

export default function Sidebar({ unread = 0 }) {
  const { admin, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    toast.success('Logged out');
    navigate('/login');
  };

  return (
    <aside className="w-56 min-h-screen bg-dark-800 border-r border-white/5 flex flex-col flex-shrink-0">
      {/* Logo */}
      <div className="px-4 py-5 border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-gradient-to-br from-primary-500 to-teal-400 rounded-xl flex items-center justify-center text-lg shadow shadow-primary-500/40">📚</div>
          <div>
            <p className="text-sm font-bold text-white leading-none">StudyNest</p>
            <p className="text-[10px] text-slate-500 mt-0.5">Library System</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-2 py-3 overflow-y-auto">
        {NAV.map(group => (
          <div key={group.group} className="mb-2">
            <p className="text-[9px] font-bold uppercase tracking-widest text-slate-600 px-3 py-2">{group.group}</p>
            {group.items.map(item => (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) =>
                  `flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 mb-0.5 ${
                    isActive
                      ? 'bg-primary-500/15 text-primary-300 border-l-2 border-primary-500'
                      : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'
                  }`
                }
              >
                <span className="text-base">{item.icon}</span>
                {item.label}
                {item.to === '/fees' && unread > 0 && (
                  <span className="ml-auto bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">{unread}</span>
                )}
              </NavLink>
            ))}
          </div>
        ))}
      </nav>

      {/* Admin profile */}
      <div className="px-4 py-4 border-t border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-br from-primary-500 to-cyan-400 rounded-lg flex items-center justify-center text-xs font-bold text-white">
            {admin?.name?.slice(0,2).toUpperCase() || 'AD'}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-white truncate">{admin?.name || 'Admin'}</p>
            <p className="text-[10px] text-slate-500">Library Owner</p>
          </div>
          <button onClick={handleLogout} className="text-slate-500 hover:text-red-400 transition" title="Logout">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
            </svg>
          </button>
        </div>
      </div>
    </aside>
  );
}
