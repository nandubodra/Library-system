-- ============================================================
-- StudyNest Library Management System — MySQL Schema
-- ============================================================

CREATE DATABASE IF NOT EXISTS studynest_library CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE studynest_library;

-- ── Admin ──────────────────────────────────────────────────
CREATE TABLE admins (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  name         VARCHAR(100)  NOT NULL,
  email        VARCHAR(150)  NOT NULL UNIQUE,
  password     VARCHAR(255)  NOT NULL,
  phone        VARCHAR(20),
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ── Library Settings ───────────────────────────────────────
CREATE TABLE settings (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  library_name    VARCHAR(150) DEFAULT 'StudyNest Library',
  address         TEXT,
  phone           VARCHAR(20),
  email           VARCHAR(150),
  logo_url        VARCHAR(255),
  upi_id          VARCHAR(100),
  upi_qr_url      VARCHAR(255),
  default_fee     DECIMAL(10,2) DEFAULT 1500.00,
  security_deposit DECIMAL(10,2) DEFAULT 2000.00,
  late_charge_per_day DECIMAL(10,2) DEFAULT 20.00,
  morning_start   TIME DEFAULT '06:00:00',
  morning_end     TIME DEFAULT '13:00:00',
  evening_start   TIME DEFAULT '14:00:00',
  evening_end     TIME DEFAULT '21:00:00',
  total_seats     INT DEFAULT 50,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ── Seats ──────────────────────────────────────────────────
CREATE TABLE seats (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  seat_number VARCHAR(10) NOT NULL UNIQUE,  -- A1, B3, etc.
  row_label   VARCHAR(5)  NOT NULL,
  status      ENUM('available','occupied','reserved') DEFAULT 'available',
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ── Students ───────────────────────────────────────────────
CREATE TABLE students (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  name             VARCHAR(100) NOT NULL,
  father_name      VARCHAR(100),
  mobile           VARCHAR(15)  NOT NULL,
  email            VARCHAR(150),
  address          TEXT,
  college          VARCHAR(200),
  course           VARCHAR(100),
  aadhaar          VARCHAR(20),
  seat_id          INT,
  photo_url        VARCHAR(255),
  joining_date     DATE         NOT NULL,
  monthly_fee      DECIMAL(10,2) NOT NULL DEFAULT 1500.00,
  security_deposit DECIMAL(10,2) DEFAULT 2000.00,
  library_timing   ENUM('morning','evening','full_day') DEFAULT 'full_day',
  status           ENUM('active','inactive') DEFAULT 'active',
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (seat_id) REFERENCES seats(id) ON DELETE SET NULL
);

-- ── Fees / Payments ────────────────────────────────────────
CREATE TABLE fees (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  student_id       INT          NOT NULL,
  month            INT          NOT NULL,   -- 1-12
  year             INT          NOT NULL,
  fee_amount       DECIMAL(10,2) NOT NULL,
  payment_status   ENUM('paid','pending','overdue') DEFAULT 'pending',
  due_date         DATE,
  payment_date     DATE,
  payment_mode     ENUM('cash','upi','bank_transfer','cheque') DEFAULT 'cash',
  transaction_id   VARCHAR(100),
  late_charge      DECIMAL(10,2) DEFAULT 0.00,
  receipt_number   VARCHAR(50) UNIQUE,
  notes            TEXT,
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  UNIQUE KEY unique_student_month (student_id, month, year)
);

-- ── Attendance ─────────────────────────────────────────────
CREATE TABLE attendance (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  student_id   INT  NOT NULL,
  date         DATE NOT NULL,
  check_in     TIME,
  check_out    TIME,
  status       ENUM('present','absent') DEFAULT 'present',
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  UNIQUE KEY unique_student_date (student_id, date)
);

-- ── Notifications ──────────────────────────────────────────
CREATE TABLE notifications (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  type        ENUM('fee_due','fee_overdue','seat_available','membership_expiring','new_student','payment_received') NOT NULL,
  message     TEXT NOT NULL,
  student_id  INT,
  is_read     BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE SET NULL
);

-- ── Indexes ────────────────────────────────────────────────
CREATE INDEX idx_students_status   ON students(status);
CREATE INDEX idx_students_seat     ON students(seat_id);
CREATE INDEX idx_fees_status       ON fees(payment_status);
CREATE INDEX idx_fees_month_year   ON fees(month, year);
CREATE INDEX idx_attendance_date   ON attendance(date);
CREATE INDEX idx_notifications_read ON notifications(is_read);

-- ── Seed Data ──────────────────────────────────────────────
INSERT INTO admins (name, email, password) VALUES
  ('Admin', 'admin@studynest.com', '$2b$10$placeholder_bcrypt_hash_here');

INSERT INTO settings (library_name, address, phone, email, upi_id, total_seats) VALUES
  ('StudyNest Library', 'Ashok Rajpath, Patna - 800004', '+91 98765 43210', 'studynest@gmail.com', 'studynest@okhdfc', 50);

-- Generate 50 seats: rows A–E, seats 1–10
INSERT INTO seats (seat_number, row_label) VALUES
  ('A1','A'),('A2','A'),('A3','A'),('A4','A'),('A5','A'),('A6','A'),('A7','A'),('A8','A'),('A9','A'),('A10','A'),
  ('B1','B'),('B2','B'),('B3','B'),('B4','B'),('B5','B'),('B6','B'),('B7','B'),('B8','B'),('B9','B'),('B10','B'),
  ('C1','C'),('C2','C'),('C3','C'),('C4','C'),('C5','C'),('C6','C'),('C7','C'),('C8','C'),('C9','C'),('C10','C'),
  ('D1','D'),('D2','D'),('D3','D'),('D4','D'),('D5','D'),('D6','D'),('D7','D'),('D8','D'),('D9','D'),('D10','D'),
  ('E1','E'),('E2','E'),('E3','E'),('E4','E'),('E5','E'),('E6','E'),('E7','E'),('E8','E'),('E9','E'),('E10','E');
